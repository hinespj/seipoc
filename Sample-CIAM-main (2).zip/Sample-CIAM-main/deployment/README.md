# Solution Deployment

This solution is designed to be deployed in either:

* [Docker Compose](./Compose)
* [Kubenetes](./Kubernetes)
  * [Helm](./Kubernetes/helm)
